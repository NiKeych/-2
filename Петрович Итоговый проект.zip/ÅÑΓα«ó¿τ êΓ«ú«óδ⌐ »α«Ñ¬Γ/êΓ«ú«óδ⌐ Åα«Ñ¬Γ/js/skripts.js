$(function() {
    let header = $('.sapka');
    let hederHeight = header.height(); 
     
    $(window).scroll(function() {
      if($(this).scrollTop() > 1) {
       header.addClass('sapka_fixed');
       $('body').css({
          'paddingTop': hederHeight+'px'
       });
      } else {
       header.removeClass('sapka_fixed');
       $('body').css({
        'paddingTop': 0 
       })
      }
    });
   });